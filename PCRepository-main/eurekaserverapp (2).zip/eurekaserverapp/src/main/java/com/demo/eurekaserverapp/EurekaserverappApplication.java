package com.demo.eurekaserverapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaserverappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaserverappApplication.class, args);
	}

}
